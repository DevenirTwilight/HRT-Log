
�
�
NativeCiHeapProbenet.plainnotes.app.data*actualProcessHeapMatchesFrozen192MiBBudget2�����:�����߯@B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.NativeCiHeapProbe-actualProcessHeapMatchesFrozen192MiBBudget.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.dataIrealArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders2�������b:��������B
emulator-5554primary�
�net.plainnotes.app.data.BackupCodec$BadFile: invalid JSON
at net.plainnotes.app.data.BackupJsonReader.parse(BackupJsonReader.kt:100)
at net.plainnotes.app.data.BackupJsonReader.indexed(BackupJsonReader.kt:36)
at net.plainnotes.app.data.BackupJsonReader.indexed$default(BackupJsonReader.kt:28)
at net.plainnotes.app.data.LibraryRestoreCoordinator.verify(LibraryRestoreCoordinator.kt:197)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restoreHeld(LibraryRestoreCoordinator.kt:115)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restore(LibraryRestoreCoordinator.kt:23)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders(LibraryRestoreAndroidTest.kt:130)
+net.plainnotes.app.data.BackupCodec$BadFile�net.plainnotes.app.data.BackupCodec$BadFile: invalid JSON
at net.plainnotes.app.data.BackupJsonReader.parse(BackupJsonReader.kt:100)
at net.plainnotes.app.data.BackupJsonReader.indexed(BackupJsonReader.kt:36)
at net.plainnotes.app.data.BackupJsonReader.indexed$default(BackupJsonReader.kt:28)
at net.plainnotes.app.data.LibraryRestoreCoordinator.verify(LibraryRestoreCoordinator.kt:197)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restoreHeld(LibraryRestoreCoordinator.kt:115)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restore(LibraryRestoreCoordinator.kt:23)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders(LibraryRestoreAndroidTest.kt:130)
"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.data@revocationRetainsOldLibraryAndNeedsExplicitFreshAuthorityToAbort2��������:��������B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-revocationRetainsOldLibraryAndNeedsExplicitFreshAuthorityToAbort.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.data>jointAliasAndStrictHeadroomRefuseBeforeAnyCandidateOrTargetKey2��������:�����ۉ[B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-jointAliasAndStrictHeadroomRefuseBeforeAnyCandidateOrTargetKey.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.dataIfailuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption2�������\:�����ɧ�B
emulator-5554primary�
�java.lang.AssertionError
at org.junit.Assert.fail(Assert.java:87)
at org.junit.Assert.assertTrue(Assert.java:42)
at org.junit.Assert.assertTrue(Assert.java:53)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption(LibraryRestoreAndroidTest.kt:173)
=java.lang.AssertionError
at org.junit.Assert.fail(Assert.java�java.lang.AssertionError
at org.junit.Assert.fail(Assert.java:87)
at org.junit.Assert.assertTrue(Assert.java:42)
at org.junit.Assert.assertTrue(Assert.java:53)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption(LibraryRestoreAndroidTest.kt:173)
"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/testlog/test-results.log 2
text/plain