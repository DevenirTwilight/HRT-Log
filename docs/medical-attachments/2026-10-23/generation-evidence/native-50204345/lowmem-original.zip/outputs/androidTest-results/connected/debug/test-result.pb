
�
�
NativeCiHeapProbenet.plainnotes.app.data*actualProcessHeapMatchesFrozen192MiBBudget2�����ے�:��������B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.NativeCiHeapProbe-actualProcessHeapMatchesFrozen192MiBBudget.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.dataIrealArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders2��������:��������B
emulator-5554primary�
�	android.database.sqlite.SQLiteException: unknown error (code 0): Queries can be performed using SQLiteDatabase query or rawQuery methods only.
at net.zetetic.database.sqlcipher.SQLiteConnection.nativeExecuteForChangedRowCount(Native Method)
at net.zetetic.database.sqlcipher.SQLiteConnection.executeForChangedRowCount(SQLiteConnection.java:818)
at net.zetetic.database.sqlcipher.SQLiteSession.executeForChangedRowCount(SQLiteSession.java:759)
at net.zetetic.database.sqlcipher.SQLiteStatement.executeUpdateDelete(SQLiteStatement.java:90)
at net.zetetic.database.sqlcipher.SQLiteDatabase.executeSql(SQLiteDatabase.java:1994)
at net.zetetic.database.sqlcipher.SQLiteDatabase.execSQL(SQLiteDatabase.java:1902)
at net.plainnotes.app.data.LibraryRestoreCoordinator.open(LibraryRestoreCoordinator.kt:190)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restoreHeld(LibraryRestoreCoordinator.kt:99)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restore(LibraryRestoreCoordinator.kt:23)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders(LibraryRestoreAndroidTest.kt:130)
'android.database.sqlite.SQLiteException�	android.database.sqlite.SQLiteException: unknown error (code 0): Queries can be performed using SQLiteDatabase query or rawQuery methods only.
at net.zetetic.database.sqlcipher.SQLiteConnection.nativeExecuteForChangedRowCount(Native Method)
at net.zetetic.database.sqlcipher.SQLiteConnection.executeForChangedRowCount(SQLiteConnection.java:818)
at net.zetetic.database.sqlcipher.SQLiteSession.executeForChangedRowCount(SQLiteSession.java:759)
at net.zetetic.database.sqlcipher.SQLiteStatement.executeUpdateDelete(SQLiteStatement.java:90)
at net.zetetic.database.sqlcipher.SQLiteDatabase.executeSql(SQLiteDatabase.java:1994)
at net.zetetic.database.sqlcipher.SQLiteDatabase.execSQL(SQLiteDatabase.java:1902)
at net.plainnotes.app.data.LibraryRestoreCoordinator.open(LibraryRestoreCoordinator.kt:190)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restoreHeld(LibraryRestoreCoordinator.kt:99)
at net.plainnotes.app.data.LibraryRestoreCoordinator.restore(LibraryRestoreCoordinator.kt:23)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders(LibraryRestoreAndroidTest.kt:130)
"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-realArchiveActivatesFreshPersistentLibraryAndRejectsOldRequestsAndReaders.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.data@revocationRetainsOldLibraryAndNeedsExplicitFreshAuthorityToAbort2��������:�����ؑ�B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-revocationRetainsOldLibraryAndNeedsExplicitFreshAuthorityToAbort.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.data>jointAliasAndStrictHeadroomRefuseBeforeAnyCandidateOrTargetKey2������ά:�������B
emulator-5554primary"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-jointAliasAndStrictHeadroomRefuseBeforeAnyCandidateOrTargetKey.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo�
�
LibraryRestoreAndroidTestnet.plainnotes.app.dataIfailuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption2�������):ƴ���B
emulator-5554primary�
�java.lang.AssertionError
at org.junit.Assert.fail(Assert.java:87)
at org.junit.Assert.assertTrue(Assert.java:42)
at org.junit.Assert.assertTrue(Assert.java:53)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption(LibraryRestoreAndroidTest.kt:164)
=java.lang.AssertionError
at org.junit.Assert.fail(Assert.java�java.lang.AssertionError
at org.junit.Assert.fail(Assert.java:87)
at org.junit.Assert.assertTrue(Assert.java:42)
at org.junit.Assert.assertTrue(Assert.java:53)
at net.plainnotes.app.data.LibraryRestoreAndroidTest.failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption(LibraryRestoreAndroidTest.kt:164)
"�

logcatandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/logcat-net.plainnotes.app.data.LibraryRestoreAndroidTest-failuresBeforeAndInsideSwitchRetainOldFactsAndReservationsWithoutAdoption.txt"�

device-infoandroid�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/device-info.pb"�

device-info.meminfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/meminfo"�

device-info.cpuinfoandroid}
{/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/HRT-Log/HRT-Log/core/data/build/outputs/androidTest-results/connected/debug/emulator-5554 - 8.0.0/testlog/test-results.log 2
text/plain