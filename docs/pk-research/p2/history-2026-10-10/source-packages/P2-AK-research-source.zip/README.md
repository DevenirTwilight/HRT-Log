# HRT Log — P2-AK independent research package

- Scientific subject: Price 1997 Figure 1 conditional digitization **intervals** for 0.5 mg and 0.25 mg SL arms, comparison to Table 1 trapezoidal AUC, and unknown predose baseline sensitivity.
- Not a clean, independently blinded second digitization. Inputs are a **single reader's proposed visual centers and broad hypothesis envelopes**, recorded for reproducibility and transparent skepticism.
- Original user-supplied scanned six-page PDF was inspected outside the archive; its full copyrighted source is not duplicated in this research archive. SHA-256 fingerprints allow provenance check.
- Original Figure 1 cropped scan is included as an examination aid and is from the user-supplied PDF, not a third-party redraw.
- 1 mg SL is independently replayed with the P2-AJ source coordinates and algorithm included here; research outcomes do not create new human observations.
- Stdlib: `python tools/p2ak_interval_audit.py`, `python tools/p2aj_original_figure_audit.py --output /tmp/one-mg.json`, `python -m unittest discover -s tools -p test_p2ak.py`, `python tools/verify_manifest.py`.
- Matplotlib: `python tools/p2ak_figures.py`.
- Key outputs: `data/p2ak-results.json`, `data/p2ak-scan-visual-intervals.json`, `data/p2aj-recomputed-1mg-control.json`, and `figures/*.png`.
- Report: `HRT_Log_P2-AK_低剂量原图追踪与区间AUC审计报告.md`.
- **Do not treat any curve, pg/mL, or AUC estimate in this package as personal dosing advice. No GitHub repository modifications.**
