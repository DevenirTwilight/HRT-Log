# P2-AP reproducible access audit

- `HRT_Log_P2-AP_报告.md`: Chinese scientific report.
- `tools/osf_inventory.py`: public OSF API metadata crawler; no downloads of participant records.
- `tools/test_osf_inventory.py`: 9 offline tests.
- `results/remote-attempt.json`: actual network attempt in this environment; unverified means no file list obtained.
- `SHA256.json`: per-file checksums.

No data license or actual IPD has been confirmed. Do not interpret an API failure as an empty or inaccessible public dataset.
