HRT Log | P2-S research-only package | 2026-10-10

This package contains exactly four NEW, additive research files:
  docs/pk-research/p2/p2s-early-growth-assay-and-data-readiness.md
  docs/pk-research/p2/p2s-early-growth-checkpoints.json
  tools/pk-research/p2s_early_growth_audit.py
  tools/pk-research/test_p2s_early_growth_audit.py

These scripts read two EXISTING research data records from your real GitHub
repository, which are intentionally NOT replaced or bundled:
  docs/pk-research/p2/p2e-source-metrics.json
  docs/pk-research/p2/p2d-komesaroff-table1.json

To reproduce: extract the four files into the root of an existing clone of
DevenirTwilight/HRT-Log, then run:

  python3 -m unittest discover -s tools/pk-research -p test_p2s_early_growth_audit.py -v
  python3 tools/pk-research/p2s_early_growth_audit.py --out /tmp/p2s-fresh-check.json

The 11 tests were run in an isolated temporary tree with source-specific
minimal fixture subsets, not as an entire GitHub repository build. The files
were not committed or pushed to GitHub by this package operation.

Research only: no independent locked human PK validation, no claims about
individual concentrations or 90% coverage, no dose or sampling-time advice.
