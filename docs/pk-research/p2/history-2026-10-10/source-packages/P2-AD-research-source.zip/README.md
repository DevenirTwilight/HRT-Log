# HRT Log P2-AD — independent pharmacokinetic research (2026-10-10)

This package is **not committed to any GitHub repository** and must stay independent while APK size optimization is underway. It does not modify production parameters, database, APK, or individual patient data.

## Contents

- `HRT_Log_P2-AD_背景与长尾可辨识性研究报告.md`: complete Chinese scientific audit, limitations and conditional outcomes.
- `tools/p2ad_baseline_tail_audit.py`: reproducible baseline-tail identifiability and hypothetical assay/design analysis.
- `tools/p2v_continuous_fit.py`: byte-for-byte unchanged P2-V research-only mathematical shape kernel.
- `tools/test_p2ad.py`: 18 independent structural, numeric, privacy and conservation tests.
- `data/p2x-conditional-ensemble-results.json`: 40 historical P2-X parameter rows, frozen input.
- `data/p2ad-audit-results.json`: full deterministic scenario and 105-pair metric data for each design.
- `figures/*.png`: illustrations generated from frozen conditions; **not observed patient PK uncertainty bands**.
- `SHA256.json`: checksums of all package content except itself.

## Reproduction

From the root of this unzipped package with Python 3.11+, NumPy, SciPy, Matplotlib:

```bash
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tools -p 'test_p2ad.py' -v
OPENBLAS_NUM_THREADS=1 python tools/p2ad_baseline_tail_audit.py --out /tmp/p2ad-new.json --figures
```

The script never overwrites its `--out` result. No network, patient records, GitHub credentials or Android SDK are needed. This package only models **conditional study-level mathematics**; it must not be deployed as an individual concentration estimator or used to recommend dosing.
