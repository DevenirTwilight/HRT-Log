# P2-AS 正式 Legacy E2_SL 模型独立科研审计

**只读 / 离线 / 无个人医疗原始数据。**

1. `HRT_Log_P2-AS_正式旧舌下E2模型独立审计报告.md`：完整中文结论、条件、引文。
2. `inputs/legacy_source_snapshot.json`：官方源码版本与Git blob校验、抄录出的参数（不是全部官方源码）。
3. `inputs/price1997_p2aj_digitization.json`：P2-AJ冻结的原文图像读数及人为宽度。
4. `inputs/p2u_study_aggregate_observations.json`：P2-U冻结的已发表组汇总观测。
5. `inputs/p2x-conditional-ensemble-results.json`：P2-X早已冻结的40行科研拟合结果，供M2已见数据比较，不能当作新外测。
6. `inputs/p2aq_osf_aggregate_audit.json`：P2-AQ之前核查的匿名汇总（无原始xlsx、无个人行、无受试者ID）。
7. `tools/legacy_audit.py`：纯Python重现旧模型、求积分、模型形状对照、条件Yaish模拟。
8. `tools/test_legacy_audit.py`：49项数值/输入/边界测试。
9. `tools/make_figures.py`：三张诊断图（只表达条件，不是临床拟合）。
10. `results/p2as-legacy-audit.json`：所有数值统计与假设。
11. `SHA256.json`：可验证每个文件的哈希。

依赖：Python 3，NumPy、SciPy、Matplotlib。`python tools/legacy_audit.py` 和 `python -m unittest discover -s tools -p 'test_legacy_audit.py' -v`。

生产模型差异说明：该脚本复制 `E2_SL` 和 `E2_ORAL` 的固定指数核，覆盖默认含服档与四档缩放，不执行 Kotlin/Gradle，也不包含个人化验拟合；因此不能声称执行了正式 Android 端到端验证。代码的数学一致性通过官方检查数值验证。使用之前从源代码获取的固定Git SHA指示来源。

研究不参与 Claude 正在进行的 PR，不推送、不修改生产源码。没有携带用户上传的OSF个体XLSX或Price付费PDF。
