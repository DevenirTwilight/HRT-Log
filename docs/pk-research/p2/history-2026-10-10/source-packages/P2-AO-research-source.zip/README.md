# HRT Log P2-AO — 独立人体 PK 数据发现与准入审计

**本包没有新的人体血药浓度数据，也没有检验 M1/M2 哪个更准确。** 只保存 2026-10-10 研究来源的公共元数据、可获取性尝试、独立性审查及防误用计算检查。

## 先读

1. `HRT_Log_P2-AO_独立人体数据发现与来源审计报告.md` — 证据、获得方式、限制。
2. `data/source-catalog.json` — 8 个来源的冻存审核记录。网址为真实外部资料页，但不代表科研包复制了原始数据。
3. `data/external-dataset-contract.json` — 将来接收匿名化逐人资料前需要的格式与来源证明。
4. `results/p2ao-source-screen.csv` — Excel 也可打开的来源审计表。
5. `contacts/作者数据申请_英文模板.md` — 3 份尚未发送的合法去标识化数据请求草稿。
6. `tools/p2ao_audit.py` — 源数据准入的 fail-closed 审计器，**只处理公开文献的元数据**。

## 本地复核

```bash
python3 tools/p2ao_audit.py
python3 -m unittest discover -s tools -p 'test_p2ao.py' -v
python3 tools/verify_manifest.py
```

Python 3.11+ 标准库即可，无网络、无外部依赖、无模型拟合、无真实病人数据。`verify_manifest.py` 检查包内各文件哈希。

## 判定术语

- `declared_available_repository` = 登记或文章**声称存在**数据仓库。并非数据已下载。
- `ipd_bytes_verified=false` = 尚未取得且确认实际文件的字节与字段。
- `not_listed_in_frozen_seven` = 不属于已知七项冻结研究；**并不自动证明**从未参与任一开发环节。
- `independence=unresolved` = 需要核验队列、招募时间、中心、先前曝光及与其他研究重叠。
- `external_score_eligible=false` = 不允许当作独立检验 M2 优劣的数据来源。

研究阶段未对 GitHub、Claude PR #1/#2、App、APK、Gradle、数据库和正式药代参数进行修改。
