# HRT Log P2-X | conditional multi-study parameter ensemble

This is **research-only**, never clinically validated personal estradiol forecasting. The published aggregates are already exposed and not independent unseen holdouts. No Doll input and no HRT Log production changes. Start with `docs/pk-research/p2/p2x-research-report.md`.

Reproduction (Python 3.11+, numpy, scipy, matplotlib):

```sh
python -m unittest discover -s tools/pk-research -p 'test_p2x*.py' -v
OPENBLAS_NUM_THREADS=1 python tools/pk-research/p2x_ensemble.py --out /tmp/p2x-rebuild.json --csv /tmp/p2x-rebuild.csv
OPENBLAS_NUM_THREADS=1 python tools/pk-research/p2x_robustness.py --out /tmp/p2x-robustness-rebuild.json
python tools/pk-research/p2x_figures.py
```

Model: exposed aggregate conditional constrained GLS, not an inferential likelihood. The 0.03/0.1/0.3 pseudo-loss slices are not posterior/confidence/clinical intervals. Code explicitly blocks overwriting result targets.
