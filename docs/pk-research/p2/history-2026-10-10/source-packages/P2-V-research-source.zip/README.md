# HRT Log P2-V 研究版连续药代模型（2026-10-10）

## 阅读入口

- `docs/pk-research/p2/p2v-continuous-model.md`：**完整报告**，来源、参数、敏感性和不可用于临床的严格边界。
- `docs/pk-research/p2/p2v-candidate-parameters.json`：模型参数与各研究独立背景/幅度，不可直接当作 App 正式人口参数。
- `docs/pk-research/p2/p2v-normalized-curves.csv`：M0/M1/M2 相对单剂 1h 的**无量纲**曲线。
- `docs/pk-research/p2/p2v-study-reconstruction.csv`：研究级组均值或人工图像的模型重构。
- `tools/pk-research/p2v_continuous_fit.py`：连续参数多研究求解、GLS 的 b/A 剖面、相关性与时间尺度敏感性、研究限定叠加。
- `tools/pk-research/p2v_stress.py`：n 扩展与逐研究排除。
- `tools/pk-research/p2v_time_split.py`：Price 1-4h 训练、6-24h 留出（**不利用未来点重校准**）。
- `research-kotlin/`：**纯研究用途** Kotlin 核与19点跨语言数值对照；没有接入正式 Android。

依赖：`python -m pip install -r tools/pk-research/p2v-requirements.txt`。运行指令详见完整报告。

### 保证

- 不使用 Doll 作为训练或定标点。
- 不改 HRT 正式药代模型、用户私人数据、数据库、P1 校准、既往冻结估算、签名或 APK。
- 已见汇总数据，非盲化外测；伪损失不是人体预测准确度。
- 所有模型数值均为研究性候选，不能当作个人剂量建议。
