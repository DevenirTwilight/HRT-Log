package net.plainnotes.research.p2v
import kotlin.math.*
fun main(){
 val p=P2VShapeParams(9,14.440199238807665,1.3518070625675727,0.249970121099137,0.5139380956563052)
 val reference=listOf(
  Pair(0.0, 0.0),
  Pair(0.001, 0.0003819303678264846),
  Pair(0.05, 0.018364049383220053),
  Pair(0.1, 0.035329059892863814),
  Pair(0.16666666666666666, 0.057060260558214247),
  Pair(0.25, 0.094855639875033301),
  Pair(0.333333333, 0.17452604675790226),
  Pair(0.5, 0.51046370245761463),
  Pair(0.6666666666666666, 0.87490706363625026),
  Pair(1.0, 1.0),
  Pair(1.5, 0.65264814373276958),
  Pair(2.0, 0.42173880855872614),
  Pair(3.0, 0.21856719994390786),
  Pair(4.0, 0.1417865432893384),
  Pair(6.0, 0.078367162754635261),
  Pair(8.0, 0.047023606717215484),
  Pair(12.0, 0.017278024390367363),
  Pair(18.0, 0.0038558761421093241),
  Pair(24.0, 0.00086051649595935288)
 )
 for ((t,y) in reference){
  val actual=P2VResearchKernel.normalized(t,p)
  check(abs(actual-y)<1e-9*max(1.0,abs(y))) {"t=$t kotlin=$actual python=$y"}
 }
 println("P2-V Kotlin↔Python conformance: ${reference.size} values passed")
 val events=listOf(P2VResearchDoseEvent(0.0,1.0),P2VResearchDoseEvent(1.0,0.5))
 val actual=P2VResearchKernel.simulateStudyAnchored(2.0,p,10.0,100.0,events)
 val expected=10.0+100.0*(P2VResearchKernel.normalized(2.0,p)+0.5)
 check(abs(actual-expected)<1e-9)
 println("P2-V Kotlin multi-event superposition passed")
}
