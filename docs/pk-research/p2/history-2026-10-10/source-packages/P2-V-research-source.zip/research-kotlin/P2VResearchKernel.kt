/**
 * P2-V RESEARCH-ONLY Kotlin kernel. No Android app hookup, no dosing decisions.
 * Identical mathematical shape to p2v_continuous_fit.py for k_fast > k_elim.
 * Params estimated from EXPOSED aggregate sources and Price manually digitized figure.
 */
package net.plainnotes.research.p2v
import kotlin.math.*

data class P2VShapeParams(
    val stageCount: Int,
    val fastRateH: Double,
    val eliminationRateH: Double,
    val slowRateH: Double?,
    val effectiveSlowWeight: Double
) {
    init {
        require(stageCount>=1)
        require(fastRateH>eliminationRateH && eliminationRateH>0)
        require(effectiveSlowWeight in 0.0..1.0)
        require(effectiveSlowWeight==0.0 || (slowRateH!=null && slowRateH>0.0))
    }
}

data class P2VResearchDoseEvent(val administeredAtHours:Double,val amountMg:Double)

object P2VResearchKernel {
    private fun bateman(t:Double,k:Double,ke:Double):Double {
        require(t>=0 && k>0 && ke>0)
        if (t==0.0) return 0.0
        val d=abs(k-ke)
        if (d<1e-9*max(k,ke)) return k*t*exp(-ke*t)
        return k*exp(-min(k,ke)*t)*(-expm1(-d*t))/d
    }

    private fun poissonUpperTail(n:Int,z:Double):Double {
        if(z==0.0)return 0.0
        if(z>=60.0 && n<=16)return 1.0
        var logFact=0.0
        for(i in 2..n)logFact+=ln(i.toDouble())
        var term=exp(n*ln(z)-z-logFact)
        var sum=term
        for(i in (n+1)..(n+500)) {
            term*=z/i
            sum+=term
            if (term<sum*1e-15)break
        }
        return sum.coerceIn(0.0,1.0)
    }

    private fun erlangResponse(t:Double,n:Int,k:Double,ke:Double):Double {
        if(n==1)return bateman(t,k,ke)
        if(t==0.0)return 0.0
        require(k>ke)
        val gap=k-ke
        return exp(n*ln(k/gap)-ke*t)*poissonUpperTail(n,gap*t)
    }

    private fun response(t:Double,p:P2VShapeParams):Double {
        val fast=erlangResponse(t,p.stageCount,p.fastRateH,p.eliminationRateH)
        val w=p.effectiveSlowWeight
        val slow=if(w==0.0)0.0 else bateman(t,p.slowRateH!!,p.eliminationRateH)
        return (1.0-w)*fast+w*slow
    }

    /** H(t) = h(t)/h(1h), dimensionless. Never a clinical blood concentration. */
    fun normalized(tHours:Double,p:P2VShapeParams):Double {
        require(tHours.isFinite()&&tHours>=0)
        val norm=response(1.0,p)
        require(norm>0 && norm.isFinite())
        return response(tHours,p)/norm
    }

    /** Explicit study-level calibration ONLY; no cross-study blanket amplitude. */
    fun reconstructStudy(tHours:Double,p:P2VShapeParams,
                         predoseBackground:Double,studyAmplitudeAt1h:Double):Double {
        require(predoseBackground.isFinite()&&predoseBackground>=0)
        require(studyAmplitudeAt1h.isFinite()&&studyAmplitudeAt1h>=0)
        return predoseBackground+studyAmplitudeAt1h*normalized(tHours,p)
    }

    /** Hypothetical linear dose superposition; requires a NAMED study-derived amplitude.
     * Neither real-person prediction nor evidence for dose linearity across products.
     */
    fun simulateStudyAnchored(queryHours:Double,p:P2VShapeParams,
                              background:Double,oneMgAt1hIncrement:Double,
                              events:List<P2VResearchDoseEvent>):Double {
        require(background.isFinite() && background>=0)
        require(oneMgAt1hIncrement.isFinite() && oneMgAt1hIncrement>=0)
        var result=background
        for(event in events){
            require(event.administeredAtHours.isFinite() && event.amountMg.isFinite() && event.amountMg>0)
            val elapsed=queryHours-event.administeredAtHours
            if(elapsed>=0)result+=oneMgAt1hIncrement*event.amountMg*normalized(elapsed,p)
        }
        return result
    }

}
