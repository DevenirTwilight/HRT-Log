# HRT Log P2-Z: clock uncertainty, not dose recommendations

P2-Z studies **already-exposed candidate models**, not original human IPD or new randomized evidence. No Doll calibration. No production app changes.

- Report: `docs/pk-research/p2/p2z-research-report.md`
- JSON: `docs/pk-research/p2/p2z-clock-envelope-results.json`
- Refined local optimization: `docs/pk-research/p2/p2z-refined-clock-results.json`
- CSV: `docs/pk-research/p2/p2z-five-fixed-clock-records.csv`
- Scripts: `tools/pk-research/p2z_clock_envelope.py`, `p2z_refine_and_validate.py`, imported numeric kernel `p2v_continuous_fit.py`
- Tests: `test_p2z.py`.

Setup Python >=3.11, NumPy, SciPy. Re-run results to new paths because outputs are intentionally write-once:

```sh
OPENBLAS_NUM_THREADS=1 python tools/pk-research/p2z_clock_envelope.py --out /tmp/p2z.json --csv /tmp/p2z.csv --log2n 11
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tools/pk-research -p 'test_p2z.py' -v
```

For local-refinement reproduction without overwriting, copy the folder to a new temporary directory and remove only the copy's `p2z-refined-clock-results.json` before running `p2z_refine_and_validate.py`.
