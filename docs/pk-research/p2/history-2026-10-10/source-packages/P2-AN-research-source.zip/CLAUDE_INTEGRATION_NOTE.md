# HRT Log / Claude: P2-AN handoff (scientific audit only)

- **Do not merge this package into production without separate review.** It audits future human-model comparison methods, not the M2 PK kernel.
- `tools/p2an_audit.py` compares **fictional MOCK_A and MOCK_B**, not real Legacy PK and experimental M2 outputs.
- New finding: sample availability that varies by evaluation time or latent signal can reverse model ordering without changing model parameters.
- Under missing scored observations, the exact full-target paired MAE difference is partially identified by the triangle inequality; if interval crosses zero label `RANK_UNDETERMINED`.
- A shared measured baseline/anchor introduces off-diagonal ratio error covariance. Use per-participant paired analysis with center/assay stratification, not per-sample independence.
- A common affine assay transform cancels in within-subject `(Y-B)/(A-B)`; nonlinear/time-dependent transforms do not necessarily cancel. None of the synthetic transforms are empirically calibrated assay corrections.
- Near-anchor signal cutoffs must be applied to **observed** noisy B/A, not the hidden truth of simulations. Preserving eligibility criteria alone cannot establish statistical accuracy.
- P2-AM input schema currently fails closed on an LLOQ-censored sample; do not silently impute half LLOQ or drop the sample to optimize model rankings.
- PR #2 M2 page and experimental data adapter should not be adjusted based on these synthetic numerical outcomes. The feature stays dimensionless and explicitly not a clinically validated personal E2 predictor.
- Do not treat `95%` synthetic bootstrap intervals as clinical 95% intervals; statistical analysis must be preregistered for genuine external data.
