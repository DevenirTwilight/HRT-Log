# P2-AN 独立验证统计审计包

**仅数学与合成数据，非任何人的真实 HRT 浓度。** 不包含 HRT Log 官方旧模型或 M2 的真实逐点预测，不能用本包给两模型排出实际胜负。

## 首先阅读

1. `HRT_Log_P2-AN_测量误差缺失机制与统计推断审计报告.md`
2. `results/p2an-analysis.json`：重放 P2-AM 合成 fixture、共享误差协方差、检测方法仿射不变性、缺失偏差、精确缺失上下界、弱锚点压力测试
3. `tools/p2an_audit.py`：全部 Python 标准库实现
4. `tools/test_p2an.py`：单元测试，报告 53 项
5. `figures/`：三张合成诊断图
6. `inputs/` 与 `tools/p2am_protocol_reference.py`：从此前 P2-AM 原始包按字节复制的合成 fixture 和协议实现

## 运行（Python 3.11+；绘图需要 matplotlib）

```bash
python3 tools/p2an_audit.py
python3 -m unittest discover -s tools -p test_p2an.py -v
python3 tools/p2an_figures.py
python3 tools/p2an_verify.py
```

`p2an_audit.py` 固定随机数种子：本轮 120 个虚构对象，两模型是刻意构造的 `MOCK_A/MOCK_B`，用途是审计统计机制。没有 P2-X/Price/Doll 的新增人体输入。  
**必须保留既有 M2 实验相对响应而不是个人 pg/mL 定位。** 研究中的手动缺失值机制/测量噪声尺度，不代表特定临床测定仪器真实性能。

## 仓库隔离

仅写入独立 `/mnt/data/p2an_stage`，不修改 GitHub、PR、Android 软件或数据库；可择时由开发者单独审查，再决定是否使用其中的验证工具。
