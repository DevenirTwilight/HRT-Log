# Redistribution notice

Source: HRT_Log_P2-AJ_%E7%8B%AC%E7%AB%8B%E7%A0%94%E7%A9%B6%E5%AE%8C%E6%95%B4%E5%8C%85.zip

The following scanned third-party journal figure image is intentionally not redistributed in this public GitHub archive; the user keeps the original local research ZIP:

- `P2-AJ/data/Price_1997_Figure_1_原始扫描裁剪.png`

The original SHA256 manifest in this archive describes the **full original** package and will report an absent image; it is preserved as provenance evidence, not an unmodified runnable tree.
