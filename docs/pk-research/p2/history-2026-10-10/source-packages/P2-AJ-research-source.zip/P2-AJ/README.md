# HRT Log / P2-AJ — Price 1997 Figure 1 first-hand facsimile pixel audit

- Research phase: P2-AJ, 2026-10-10.
- Purpose: source facsimile verification; broken-axis pixel calibration; 1mg SL nine-point digitization; AUC consistency stress test.
- **Not a clinical prediction model**. Not independent blinded human PK validation.
- **Not a GitHub repo change**. No production build files were touched.
- The image and pixel coordinates originated from the user's already-uploaded 1997 journal article scanned reproduction; check PDF source SHA-256 in `data/p2aj-manual-figure1-reading.json`.
- 0.5mg and 0.25mg source plot lines overlap; not yet fully independent re-digitizations.

## Run

```bash
python tools/p2aj_original_figure_audit.py --output /tmp/p2aj-recomputed.json
python -m unittest discover -s tools -p 'test_p2aj.py' -v
python tools/p2aj_figures.py
python tools/verify_manifest.py
```

Full Chinese scientific report: `HRT_Log_P2-AJ_原刊扫描重新读图与AUC复核报告.md`.
