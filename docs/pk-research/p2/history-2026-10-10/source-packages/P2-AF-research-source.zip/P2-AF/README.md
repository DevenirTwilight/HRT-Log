# P2-AF · HRT Log experimental SL estradiol PK model research

Independent off-repository research package, 2026-10-10. **GitHub/PR/APK/Gradle/DB unchanged.**

**Aim:** Analyze conditional stability of pharmacokinetic *functionals* when both central elimination (`k_e`) and slow-input rate (`k_s`) vary, while profiling nonnegative background and both independent absorption gains. No patient samples; all synthetic truth curves originate from the already-exposed P2-X Price1997 Figure 1 model anchors.

**Important:** Results are deterministic mathematical *within-candidate compatible envelopes*. They are NOT human confidence intervals, drug level forecasts, biological parameter estimates or clinical validation.

Contents:
- `HRT_Log_P2-AF_联合速率与预测函数稳健性研究报告.md`: detailed Chinese technical report and scientific limitations.
- `data/p2x-conditional-ensemble-results.json`: frozen 40-row P2-X conditional fit source (not individual subject data).
- `data/p2af-joint-parameter-functions.json`: 15 source candidates × 5 synthetic scenarios × accepted-grid functional minima/medians/maxima.
- `data/p2af-grid-stress.json`: nested 37×23 vs 73×45 grid refinement audit.
- `data/p2af-run-summary.txt`, `data/p2af-unit-test-log.txt`: actual execution audit.
- `tools/p2af_joint_ke_ks.py`, `tools/p2af_grid_stress.py`: runnable analysis and nested-grid checks.
- `tools/p2v_continuous_fit.py`: original independent P2-V numeric kernel.
- `tools/p2af_figures.py`: deterministic plot regeneration.
- `tools/test_p2af.py`: tests for mathematical invariants and outputs.
- `figures/`: four scientific diagnostic figures.
- `SHA256.json` and `tools/verify_manifest.py`: check integrity of all packaged files other than the manifest itself.

## Run

Requires `numpy`, `scipy`, `matplotlib`; Python 3.10+.

```bash
export OPENBLAS_NUM_THREADS=1
python tools/p2af_joint_ke_ks.py --output /tmp/p2af-rebuild-joint.json
python tools/p2af_grid_stress.py --output /tmp/p2af-rebuild-grid.json
python -m unittest discover -s tools -p test_p2af.py -v
python tools/verify_manifest.py
```

`--output` refuses to overwrite any existing results. Changes to grid definitions or scientific assumptions must create **new** study artifacts, not silently alter these frozen P2-AF outputs.
