# P2-AE independent research bundle — 2026-10-10

This directory is a completely offline mathematical research artifact. It was deliberately **not** pushed into the HRT Log repository, since another contributor is optimizing/compressing the APK.

Research question: In the exposed-study conditional M2 sublingual estradiol model, how much of an apparently identified slow absorption rate actually depends on freezing the unknown fast/slow input mixture and baseline?

The P2-X 40 source-conditional fits in `data/p2x-conditional-ensemble-results.json` and exact old P2-V shape kernel in `tools/p2v_continuous_fit.py` are provenance copies, **not newly observed human PK data**. They must not be counted as independent locked external validation. No Doll calibration or clinical dosing recommendation.

### Reproduce independently in an offline Python environment

Python 3.10+, NumPy, SciPy, Matplotlib. Root directory is the directory holding `data`, `tools`, `figures`.

```sh
export OPENBLAS_NUM_THREADS=1
python tools/p2ae_tail_gain_profile.py --output /tmp/p2ae-main.json
python tools/p2ae_cross_model_profiles.py --output /tmp/p2ae-cross.json
python tools/p2ae_drift_stress.py --output /tmp/p2ae-drift.json
python tools/p2ae_precision_stress.py --out /tmp/p2ae-precision.json
python tools/p2ae_extra_figures.py
python -m unittest discover -s tools -p test_p2ae.py -v
python tools/verify_manifest.py
```

The script refuses to overwrite existing JSON output. `p2ae_extra_figures.py` redraws the six PNG figures inside this *extracted research directory only*. Timing may depend on CPU and SciPy build; the slow-rate profile is finite grid, not global nonlinear optimization.

Important limitations: all measurements (other than source-conditional anchor values) are synthetic expected group concentrations; model-pair distance 2 is **not** a 95% CI, clinical power, or a statement about a real patient's blood level. Late measurements beyond 24 h and hypothesized drift/noise are extrapolated. The profile conditions on each candidate's own fixed n_fast,k_fast,k_elim; it **cannot establish individual parameter identification or actual error coverage**.

Evidence sources and interpretation in `HRT_Log_P2-AE_联合可辨识性与跨候选竞争研究报告.md`.
