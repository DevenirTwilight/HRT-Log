# HRT Log P2-U 独立研究包

只读跨研究汇总数据离线拟合，不含任何个人信息、不改正式药代模型，不保证临床准确性。

- 报告 `docs/pk-research/p2/p2u-cross-study-joint-constraints.md`
- 来源数值 `docs/pk-research/p2/p2u-observed-aggregates.json`
- 结构化结果 `docs/pk-research/p2/p2u-fit-results.json`
- 可复现源码 `tools/pk-research/p2u_joint_constraints.py`
- 单元测试 `tools/pk-research/test_p2u_joint_constraints.py`
- 依赖 `tools/pk-research/p2u-requirements.txt`

请在现有 HRT-Log 仓库根目录解压并仅以独立研究工具运行。不要覆盖已有文件，或直接升级正式 E2_SL 参数。
