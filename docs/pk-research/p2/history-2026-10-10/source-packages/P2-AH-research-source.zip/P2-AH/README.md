# P2-AH: Price 1997 AUC definition & frozen digitization consistency audit

Independent research package dated 2026-10-10. It DOES NOT contain individual concentrations, and DOES NOT change HRT Log or the experimental GitHub PR.

## Files

- `data/p2u-observed-aggregates.json`: byte-for-byte previous P2-U source input.
- `data/p2ah-price-auc-audit.json`: independently computed trapezoid scenarios, read-width stress, mean/AUC commutation and half-life sensitivity.
- `tools/p2ah_price_auc_audit.py`: self-contained calculation using Python stdlib only.
- `tools/test_p2ah.py`: 24 tests.
- `tools/p2ah_figures.py`: optional Matplotlib+NumPy figures.
- `HRT_Log_P2-AH_原文AUC口径与图表一致性研究报告.md`: Chinese scientific report with article links.
- `SHA256.json`: payload SHA-256 manifest.
- `tools/verify_manifest.py`: standalone verification.

## Scope

The primary source is a publicly posted full-text transcription of Price 1997. It explicitly states **predose-corrected** noncompartmental parameters, **AUC0–24**, and **trapezoidal integration**. The input Figure 1 values are P2-U analyst digitization, *not* numeric source tables. Numeric mismatch is an unresolved source reconciliation issue, not evidence of research fraud.

## Reproduction

```bash
python tools/p2ah_price_auc_audit.py --output /tmp/p2ah-check.json
python -m unittest discover -s tools -p 'test_p2ah.py' -v
python tools/p2ah_figures.py
python tools/verify_manifest.py
sha256sum data/p2ah-price-auc-audit.json /tmp/p2ah-check.json
```

No production PK model update or personalized estradiol predictions authorized.
