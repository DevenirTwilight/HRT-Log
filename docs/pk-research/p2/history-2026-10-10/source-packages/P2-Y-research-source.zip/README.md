# HRT Log P2-Y — conditional study-level moment and dosing-clock audit

**Research only.** No drug-dose guidance or validated individual concentration predictions.

Inputs use **pre-exposed** P2-X candidate M2 model parameter rows, rather than refitting any data. Authors' reported Yaish mean+SD before and after a 0.5mg SL dose are compared under explicitly *hypothetical* four-doses-per-day clocks. Original Price PDF methods checked; no PDF redistributed.

See `docs/pk-research/p2/p2y-research-report.md` for evidence, mathematical assumptions and results. Confirmatory prospective validation remains outstanding.

Run from this archive's root (Python 3.11+, numpy/scipy):

```sh
OPENBLAS_NUM_THREADS=1 python tools/pk-research/p2y_hierarchical_moment_audit.py --out /tmp/p2y-moments.json
OPENBLAS_NUM_THREADS=1 python tools/pk-research/p2y_dose_clock_sensitivity.py --json /tmp/p2y-clock.json --csv /tmp/p2y-clock.csv
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s tools/pk-research -p 'test_p2y.py' -v
```

Published inputs: Price et al. 1997 DOI 10.1016/S0029-7844(96)00513-3; Yaish et al. 2023 DOI 10.1089/trgh.2023.0022. Rosano/Komesaroff/Price exposed fits inherited from P2-X.
