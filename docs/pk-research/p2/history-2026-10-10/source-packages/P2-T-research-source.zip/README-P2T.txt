HRT Log P2-T independent research handoff (2026-10-10)

Place the docs/ and tools/ directories into a working copy of the HRT-Log repository, without overwriting any older P2 sources.
Run from repo root:
  python3 -m unittest discover -s tools/pk-research -p test_p2t_acquisition_audit.py -v
  python3 tools/pk-research/p2t_acquisition_audit.py --out /tmp/p2t-fresh.json

Files:
- docs/pk-research/p2/p2t-data-acquisition-and-cohort-identity.md
- docs/pk-research/p2/p2t-acquisition-ledger.json
- docs/pk-research/p2/p2t-acquisition-checkpoints.json
- tools/pk-research/p2t_acquisition_audit.py
- tools/pk-research/test_p2t_acquisition_audit.py

The audit is read-only source metadata. It has no user data and no clinical validation. It does not contact investigators, download private datasets, alter HRT Log production models, or approve new APKs.
