# HRT Log P2-AM：独立验证设计与合成时间戳压力测试

**研究性质**：使用 P2-X 15 套已有条件 M2 曲线研究时间记录误差，并提供严格的**未来独立人体数据验证**程序；无新人体数据、没有患者级预测准确率。研究期间**未修改 GitHub 仓库、APK 或 PR #1**。

## 优先阅读

1. `HRT_Log_P2-AM_独立人体验证协议与时间记录敏感性报告.md`：结论、完整验证设计、前提与科研限制。
2. `results/p2am-clock-sensitivity.json`：29 组（时间×扰动）数学计算，15 套冻结候选；完整结果。
3. `tools/p2am_protocol.py`：未来验证程序原型，含资格、来源隔离、双模型成对评分与防误用门槛。
4. `synthetic/`：仅为验证代码正确性而生成的 8 个虚构对象。**其曲线预测不是官方 Legacy/M2 引擎输出，不得据此选择模型。**
5. `inputs/`：已有 P2-X 和 P2-AL 输入，仅供独立复算与追溯。

## 独立复算

运行环境：Python 3.11+，`numpy`、`scipy`；绘图另需 `matplotlib`。本次执行环境：NumPy 2.3.5、SciPy 1.17.0、matplotlib 3.10.8；不是软件最低版本承诺。

```bash
python3 tools/p2am_timing.py
python3 tools/p2am_make_synthetic.py
python3 tools/p2am_protocol.py
python3 -m unittest discover -s tools -p 'test_p2am.py' -v
python3 tools/p2am_figures.py
python3 tools/p2am_verify.py
```

独立验证必须由外部拥有数据授权、研究伦理审查、临床/检验人员共同设计；本脚本只检验**预先锁定的一次给药形状验证方法**，并不自动构成临床研究合规证明。脚本会拒绝既往见过的研究、没有前瞻锁定时间戳的模型、未量化浓度或非 SL-E2 输入。

**绝对血清 E2 的 pg/mL 独立预测 Gate 始终标为 BLOCKED。** 研究中的一次实测锚点不能用于声称模型能够不经校准预测个人浓度。

注意：未来如加载真实病人数据，应使用机构授权的离线安全环境，不能把原始医疗数据或明细输出上传到 GitHub／Claude／ChatGPT。本工具对人类样本默认不将受试者明细写入磁盘；但输入数据处理和机构级的隐私风险仍必须进行单独审查。
