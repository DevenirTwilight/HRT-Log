# P2-AI independent research handoff

Objective: provenance-aware Price 1997 Figure 1 vs Table 1 AUC math, read-width lower bounds, and sublingual dose-proportionality audit.

**Critical limitation:** The original typeset Price Figure 1 raster and participant records were not available. No independent original journal figure re-digitization has been performed. The online 2018 Wikimedia replot is only a secondary qualitative comparison based on the same study.

This pack is self-contained for deterministic calculations with Python 3 standard library; plotting requires Matplotlib. Source points are copied without modification from P2-U (SHA-256 in JSON); Table1 means/SD are explicitly transcribed from online article text, subject to original journal plate checking.

Commands:

```bash
python tools/p2ai_primary_source_consistency.py --out /tmp/p2ai-regen.json
python -m unittest discover -s tools -p 'test_p2ai.py' -v
python tools/p2ai_make_figures.py
python tools/verify_manifest.py
sha256sum /tmp/p2ai-regen.json data/p2ai-source-constraints.json
```

No production code or GitHub commits are part of this pack.
