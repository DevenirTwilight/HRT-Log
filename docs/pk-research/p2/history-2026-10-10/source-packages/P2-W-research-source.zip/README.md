# P2-W: HRT Log research-only reproducibility bundle

Start with `docs/pk-research/p2/p2w-repeated-dose-transfer.md`.

## Run

```sh
python -m pip install -r tools/pk-research/p2w-requirements.txt
python -m unittest discover -s tools/pk-research -p 'test_p2w_repeat_constraint.py' -v
python tools/pk-research/p2w_repeat_constraint.py --out /tmp/p2w-fresh.json --csv /tmp/p2w-fresh.csv
```

Only already exposed public cohort summaries and research-fitted historical parameters; no Doll, patient data, private repository data, production APK, treatment advice, or automated clinical approval.

All concentration indices are *dimensionless*, NOT individual predictions.
