# HRT Log / P2-AQ — real OSF workbooks, privacy-minimized audit

**This ZIP does not contain the participant-level Excel workbooks or the two original OSF ZIPs.** The user has those separately. The included aggregate audit result was computed from genuine workbooks uploaded on 2026-10-10.

## Findings

- TCRUW: 30 participant rows, 96 columns; E2 measurements at baseline and 6-month follow-up, no dose-relative dense PK observations.
- VNC54: 22 participant rows, 128-column main Data sheet + 6 questionnaire sheets.
- VNC54: 90-minute post-morning-0.5-mg sublingual E2 values at 3 months (n=10) and 6 months (n=11), in the same 11 people (10 with repeated post values).
- VNC54 6-month 90min median 1721 pmol/L and half-sample IQR 999.9–2432 reproduce Yaish 2023 published summary. This is **previously exposed** evidence, not a newly blinded cohort.
- Data source: https://doi.org/10.17605/OSF.IO/VNC54 ; https://doi.org/10.17605/OSF.IO/TCRUW
- Method: https://pmc.ncbi.nlm.nih.gov/articles/PMC10732161/
- Neither dataset supports external 0–24-hour curve validation or personal absolute pg/mL prediction.

## Recalculate with original ZIP files

Requires Python 3 + artifact_tool. Pass each original ZIP to the script using explicit CLI arguments:

```bash
python audit_osf_estradiol.py --tcruw /path/to/tcruw-osfstorage-archive.zip --vnc54 /path/to/vnc54-osfstorage-archive.zip --out audit/p2aq_aggregate_audit.json
python -m unittest discover -s tests -p 'test_*.py' -v
python make_figures.py
```

Inputs are only read within a temporary folder, no external network, and program prints only aggregate counts and hashes. Do not commit patient-level workbooks into the software repository, and do not infer that the 52 participant rows represent 52 independent individuals.

## Layout

- `audit_osf_estradiol.py`: input security, extract XLSX, read via artifact_tool, aggregate audit.
- `audit/p2aq_aggregate_audit.json`: real-workbook machine-readable aggregate evidence with source hashes.
- `tests/test_p2aq.py`: unit and synthetic-table tests; source workbooks not required for these tests.
- `audit/test_results.txt`: test transcript.
- `make_figures.py`, `figures/`: published subgroup aggregate plot.
- Chinese report, README, SHA256 manifest.
