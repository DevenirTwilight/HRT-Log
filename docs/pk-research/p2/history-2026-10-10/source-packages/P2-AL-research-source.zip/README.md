# HRT Log P2-AL（2026-10-10）：离线模型验收审计

该 ZIP 是**独立科研包**。不包含正式临床验证数据，不修改 GitHub 仓库，也不与 APK 压缩/Claude 的开发分支冲突。

## 内容

- `HRT_Log_P2-AL_模型验收门槛与重读图稳健性报告.md`：完整科学解释、数学推导、10 个敏感性情景和研究/工程双层 Gate。
- `inputs/`：来自 P2-AG/P2-AF/P2-AJ/P2-AK 的 **5 个冻结研究 JSON**。不是新增观测。
- `tools/p2al_acceptance.py`：标准库，按固定前期模型形状进行 Price 重读图交叉审计并求严格的视觉矩形区间极值。
- `tools/test_p2al.py`：30 项单元与边界测试，包括 256 个端点枚举的回归验证。
- `tools/p2al_figures.py`：可选的 matplotlib 图表重绘脚本。
- `results/p2al-audit.json` / `p2al-paired-comparison.csv` / `p2al-gates.json`：机读结果。
- `figures/`：两张说明性图。
- `SHA256.json`：研究包成员的 SHA-256 文件清单（不包含清单本身）。

## 解压复算

```bash
python3 tools/p2al_acceptance.py
python3 -m unittest discover -s tools -p 'test_p2al.py' -v
python3 tools/verify_manifest.py
# 可选：需要 matplotlib
python3 tools/p2al_figures.py
```

## 模型意义

M1、M2 是 P2-AG 训练产生的**研究模型族**，不是 App 里的正式旧模型与新 M2 的临床头对头验证。使用 1h Price 组均值重标定了研究级幅度，因此表中的绝对数值仅是条件重建，不能用于个人 pg/mL；主观读图区间也不是概率/置信区间。
