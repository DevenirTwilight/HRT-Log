# HRT Log · P2-AG 离线跨研究留出外推审计

**完全独立研究包**（2026-10-10）。没有修改 GitHub / HRT Log / PR / Android / APK / 数据库。研究来源此前已暴露，Price 为人工数字化图线；该研究不是盲化人体外部验证，不提供个人 E2 浓度或给药建议。

## 快速结论

Rosano 和 Komesaroff 只有 7 个不晚于 1h 的组级观测点；M2 具有 4 个共享形状连续参数和 4 个研究级背景／幅度干扰参数（8个自由度），在这些早期点上拟合伪损失几乎为零，但经 Price 1h 单点幅度校准后，留出 Price 2–24h 仍可能明显偏离。对于 Price 人为背景24 pg/mL，早期 M2 在2h预测154.4 pg/mL，Price既有人工读图约225 pg/mL。

详细证据、假设与局限：`HRT_Log_P2-AG_跨研究留出外推与过拟合审计报告.md`。

## 文件

- `tools/p2ag_cross_source.py` 原始早期两来源重新优化，共48次局部拟合（16种cap/模型/n组合，每个3个起点）；Price1h锚定、2–24h留出。
- `tools/p2ag_diagnostics.py` 20个条件情景统计表、JSON摘要、三张图。
- `tools/p2v_continuous_fit.py` 从P2-V复制的数学核。
- `tools/test_p2ag.py` 19项防泄漏和数值验收测试。
- `tools/verify_manifest.py` 对压缩包输入／输出逐文件 SHA-256 校验。
- `data/` P2-U人工组均值与P2-X结果、P2-AG完整拟合JSON及条件汇总CSV。
- `figures/` 三张可视化。

## 如何复现

```bash
export OPENBLAS_NUM_THREADS=1
python tools/p2ag_cross_source.py --output /tmp/p2ag-new.json
python tools/p2ag_diagnostics.py
python -m unittest discover -s tools -p 'test_p2ag.py' -v
python tools/verify_manifest.py
```

默认禁止覆盖已经存在的结果输出。数据不是独立未见人体资料；不能用本研究替换正式 E2_SL 的 pg/mL 预测。
