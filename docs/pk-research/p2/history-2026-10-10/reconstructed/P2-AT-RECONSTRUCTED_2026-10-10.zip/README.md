# P2-AT retrospective calculation reconstruction — not the lost original archive

Date: 2026-10-10. The original P2-AT standalone ZIP has not been located. Its original SHA-256 was recorded as `a636beee77525043a69a8393d88d03b20d9ee14adf2e29c6995960b192b4c14a` and its size as 390,066 bytes; **the file in this directory is not that original**.

The scientific inputs have been recovered from **P2-AS**'s original complete research package (legacy production formula transcription, P2-AJ original figure digitized data *numbers*, P2-U group observations, P2-X frozen candidate rows). This version independently recomputes the late-stage Legacy-vs-M2 shape audit and 30-day hypothetical q6h tail indicator.

The copied P2-AS reference kernel is retained under `tools/legacy_audit.py` **unchanged**, and source JSON snapshots are under `inputs/`. No original scanned journal image or raw OSF individual-level Excel is included. This is a stand-alone research archive without changes to production HRT Log.

Reproduce: `python3 -m pip install numpy scipy` followed by `python3 -m unittest discover -s tools -p test_p2at_reconstruct.py -v`; `python3 tools/p2at_reconstruct.py --out /tmp/p2at-recheck.json` (will refuse to overwrite an existing file). A frozen generated result is `results/p2at-reconstructed.json`. The tests exercise descriptive agreement with the already-saved historical summary; they are not validation on independent human records.

**Scientific warning:** Price, Rosano and Komesaroff already influenced M2 design and candidate selection. Better retrospective fit does not establish real-world patient concentration prediction or clinical dose advice. The old model is not clinically validated simply by being in production, either. The full source ZIP remains missing, and any genuinely recovered copy must be retained separately, not overwritten by this reconstruction.
