import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import p2at_reconstruct as p


class ReconstructedAuditTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d = p.compute()

    def test_original_not_falsely_recovered(self):
        self.assertFalse(self.d['original_zip_recovered'])
        self.assertEqual(self.d['status'], 'RECONSTRUCTED_NOT_ORIGINAL')

    def test_frozen_15_candidates(self):
        self.assertEqual(self.d['candidate_count'], 15)

    def test_legacy_price_rms(self):
        q = self.d['price1997']['results_by_assumed_background'][0]
        self.assertAlmostEqual(q['legacy_rmse_2to24'], .11665, delta=.00003)
        self.assertAlmostEqual(q['m2_rmse_min'], .00903, delta=.00003)
        self.assertAlmostEqual(q['m2_rmse_max'], .05313, delta=.00003)

    def test_exposed_price_all_m2_lower(self):
        self.assertTrue(all(row['all_m2_better_than_legacy_on_exposed_points']
                            for row in self.d['price1997']['results_by_assumed_background']))

    def test_rosano_early_errors(self):
        x=self.d['rosano1997']
        self.assertAlmostEqual(x['legacy_rmse'], .29361, delta=.00003)
        self.assertAlmostEqual(x['m2_rmse_min'], .03885, delta=.00003)
        self.assertAlmostEqual(x['m2_rmse_max'], .10840, delta=.00003)

    def test_komesaroff_ratio(self):
        x=self.d['komesaroff1998']
        self.assertAlmostEqual(x['observed_15min_to30min_increment_ratio'], .21132, delta=.00003)
        self.assertAlmostEqual(x['legacy_ratio'], .64200, delta=.00003)
        self.assertAlmostEqual(x['m2_ratio_min'], .11732, delta=.00003)
        self.assertAlmostEqual(x['m2_ratio_max'], .22325, delta=.00003)

    def test_synthetic_q6_24h(self):
        x=self.d['repeated_dose_synthetic']
        self.assertAlmostEqual(x['legacy_dimless'], .000894, delta=.000003)
        self.assertAlmostEqual(x['m2_dimless_min'], .000832, delta=.000003)
        self.assertAlmostEqual(x['m2_dimless_max'], .167938, delta=.000003)

    def test_not_clinical(self):
        self.assertFalse(self.d['production_replacement_authorized'])
        self.assertTrue(self.d['not_external_validation'])
        self.assertEqual(self.d['unseen_patient_pk_series'], 0)

if __name__ == '__main__': unittest.main()
