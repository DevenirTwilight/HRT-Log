#!/usr/bin/env python3
"""Recompute lost original P2-AT study from recovered P2-AS independently archived inputs.

RECONSTRUCTION 2026-10-10, NOT a restored original P2-AT ZIP. All input
studies were already exposed to model development; not external validation.
This script never estimates individual concentrations or recommends dosing.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import legacy_audit as a

ROOT = Path(__file__).resolve().parents[1]
BASELINES = (0, 6, 12, 18, 24)


def candidates():
    best = a.M2['summary']['global_best_loss']
    selected = [r for r in a.M2['rows'] if r['score'] <= best + 0.10 + 1e-10]
    if len(selected) != 15:
        raise RuntimeError('Frozen candidate set not 15; stop/review the source')
    return selected


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compute():
    pool = candidates()
    price = []
    times = [x['hour'] for x in a.PRICE['digitized_points'] if x['hour'] > 1]
    for b in BASELINES:
        pts = a.stats_price(b)
        observations = [p['observed_relative'] for p in pts['points'] if p['h'] > 1]
        m2errs = [a.rmse([a.m2_relative(t, r) for t in times], observations) for r in pool]
        price.append({'assumed_baseline_pg_ml': b,
                      'legacy_rmse_2to24': pts['rmse_t2_to24'],
                      'm2_rmse_min': min(m2errs), 'm2_rmse_max': max(m2errs),
                      'frozen_candidate_count': len(m2errs),
                      'all_m2_better_than_legacy_on_exposed_points': all(e < pts['rmse_t2_to24'] for e in m2errs)})
    ros = a.OBS['Rosano1997_PK25']
    rs = list(zip(ros['hours'], ros['y']))
    pred_old = [a.rel(t) for t, _ in rs[:-1]]
    obs = [y / rs[-1][1] for _, y in rs[:-1]]
    scores = [a.rmse([a.m2_relative(t, r) for t, _ in rs[:-1]], obs) for r in pool]
    old_score = a.rmse(pred_old, obs)
    kom = a.komesaroff()
    m2ratio = [a.m2_relative(.25, r) / a.m2_relative(.5, r) for r in pool]
    # The legacy P2-AT 30-day experiment: 1mg q6h, last dose time=0,
    # then a 24h interval without a new dose. Denominator is H(1h) per model.
    q6 = 24.
    n_doses = 30 * 24 // 6
    old_tail = sum(a.rel(q6 + 6*i) for i in range(n_doses))
    m2_tail = [sum(a.m2_relative(q6 + 6*i, r) for i in range(n_doses)) for r in pool]
    input_files = sorted((ROOT / 'inputs').glob('*.json'))
    return {
      'phase': 'P2-AT', 'status': 'RECONSTRUCTED_NOT_ORIGINAL',
      'created_on': '2026-10-10', 'original_zip_recovered': False,
      'original_zip_sha256_from_historical_manifest': 'a636beee77525043a69a8393d88d03b20d9ee14adf2e29c6995960b192b4c14a',
      'original_zip_bytes_from_historical_manifest': 390066,
      'basis': 'P2-AS original audit formulas and its frozen P2-AJ/P2-U/P2-X input snapshots',
      'input_sha256': {f.name: digest(f) for f in input_files},
      'candidate_count': len(pool), 'candidate_selection': 'P2-X score <= global_best_loss + 0.10; frozen before comparison',
      'price1997': {'source': 'non-blind manual figure digitization; group means (already exposed)', 'results_by_assumed_background': price},
      'rosano1997': {'baseline_assumed_pmol_l': 0, 'observed_relative_10_20_40min': obs,
                      'legacy_relative_10_20_40min': pred_old,
                      'legacy_rmse': old_score, 'm2_rmse_min': min(scores), 'm2_rmse_max': max(scores)},
      'komesaroff1998': {'observed_15min_to30min_increment_ratio': kom['observed_15min_increment_to_30min_increment'],
                          'legacy_ratio': kom['legacy_15min_to_30min_response'],
                          'm2_ratio_min': min(m2ratio), 'm2_ratio_max': max(m2ratio)},
      'repeated_dose_synthetic': {'dose_mg': 1, 'q_hours': 6, 'dosing_days': 30,
                                   'hours_since_final_dose': 24, 'anchor': 'each model 1h single-dose = 1',
                                   'legacy_dimless': old_tail, 'm2_dimless_min': min(m2_tail),
                                   'm2_dimless_max': max(m2_tail)},
      'not_external_validation': True, 'unseen_patient_pk_series': 0,
      'no_individual_absolute_pg_ml_prediction_proven': True,
      'production_replacement_authorized': False,
      'limitations': ['not the original P2-AT research code or archive',
                      'Price/Rosano/Komesaroff used in M2 development (data leakage)',
                      'Price Figure/Table AUC remains unresolved',
                      'model shapes normalized using individual model peak, not a patient measurement',
                      'sampling timestamps, assay errors, long tail and individual amplitudes unverified']
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Refusing to overwrite existing output')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(compute(), ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(str(args.out))

if __name__ == '__main__':
    main()
